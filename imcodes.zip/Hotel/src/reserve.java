import com.sun.tools.javac.Main;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import javax.swing.JOptionPane;




    public class reserve extends javax.swing.JFrame {
    public reserve() {
        initComponents();
        Connect();
        Loadroom ();
    }
    
    Connection con;
    PreparedStatement pst;
    DefaultTableModel d;
    ResultSet rs;
    
    public void Connect (){
        
        try {
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/account", "root", "");    
    } catch (ClassNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 
    public void Loadroom (){
        
       
        try {
            int c;
            pst = con.prepareStatement("select * from reserved_accs");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            d = (DefaultTableModel)table.getModel();
            d.setRowCount(0);
            
            while(rs.next()){
                
                Vector v2 = new Vector();
                
                for (int i = 1; i<=c; i++) {
                    v2.add(rs.getString("name"));
                    v2.add(rs.getString("cp_num"));
                    v2.add(rs.getString("r_type"));
                    v2.add(rs.getString("check_in"));
                    v2.add(rs.getString("check_out"));
                    v2.add(rs.getString("amount"));   
                }
                
                d.addRow(v2);
    
            }
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        num = new javax.swing.JTextField();
        in = new javax.swing.JTextField();
        out = new javax.swing.JTextField();
        room = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel1.setText("RESERVATION FORM");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(385, 19, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 94, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Room Type");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 198, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Check In");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Check Out");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Contact Number");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 144, -1, -1));
        getContentPane().add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 92, 190, -1));
        getContentPane().add(num, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 144, 190, -1));
        getContentPane().add(in, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 248, 190, -1));
        getContentPane().add(out, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 300, 190, -1));

        room.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Standard", "Deluxe", "Premium", "Regency" }));
        room.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomActionPerformed(evt);
            }
        });
        getContentPane().add(room, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 196, 190, -1));

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Number", "Room Type", "In", "Out", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(442, 92, 533, 233));

        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(727, 383, 100, 35));

        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(864, 383, 99, 35));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Total");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 355, 37, -1));
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(207, 355, 190, -1));

        save.setText("Save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        getContentPane().add(save, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 383, 100, 35));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/reservation.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 450));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        String namee = name.getText();
        String number = num.getText();
        String rtype = room.getSelectedItem().toString();
        String cin = in.getText();
        String cout = out.getText();
        String ttl = total.getText();
        
        try {
            pst = con.prepareStatement("insert into reserved_accs (name, cp_num, r_type, check_in, check_out, amount) values (?, ?, ?, ?, ?, ?)");
            pst.setString(1, namee);
            pst.setString(2, number);
            pst.setString(3, rtype);
            pst.setString(4, cin);
            pst.setString(5, cout);
            pst.setString(6, ttl);
            pst.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Room Saved!");
            
            name.setText("");
            num.setText("");
            room.setSelectedIndex(-1);
            in.setText("");
            out.setText("");
            total.setText("");
            
        
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }//GEN-LAST:event_saveActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        String namee = name.getText();

        try {
            pst = con.prepareStatement("delete from reserved_accs where name=?");
            pst.setString(1, namee);
            
            pst.executeUpdate();
            if (table.getSelectedRowCount()==1) {
            d.removeRow(table.getSelectedRow());
            JOptionPane.showMessageDialog(this, "Room Deleted!");
            } else {
                JOptionPane.showMessageDialog(this, "Please select a row to delete!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            name.setText("");
            num.setText("");
            room.setSelectedIndex(-1);
            in.setText("");
            out.setText("");
            total.setText("");
        
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        String namee = name.getText();
        String number = num.getText();
        String rtype = room.getSelectedItem().toString();
        String cin = in.getText();
        String cout = out.getText();
        String ttl = total.getText();
        
        try {
            pst = con.prepareStatement("update reserved_accs set cp_num=?, r_type=?, check_in=?, check_out=?, amount=? where name=?");
            pst.setString(1, namee);
            pst.setString(2, number);
            pst.setString(3, rtype);
            pst.setString(4, cin);
            pst.setString(5, cout);
            pst.setString(6, ttl);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Room Updated!");
            
            name.setText("");
            num.setText("");
            room.setSelectedIndex(-1);
            in.setText("");
            out.setText("");
            total.setText("");
        
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_updateActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        d = (DefaultTableModel)table.getModel();
        int selectIndex = table.getSelectedRow();
        
        name.setText(d.getValueAt(selectIndex, 0).toString());
        num.setText(d.getValueAt(selectIndex, 1).toString());
        room.setSelectedItem(d.getValueAt(selectIndex, 2).toString());
        in.setText(d.getValueAt(selectIndex, 3).toString());
        out.setText(d.getValueAt(selectIndex, 4).toString());
        total.setText(d.getValueAt(selectIndex, 5).toString());
    }//GEN-LAST:event_tableMouseClicked

    private void roomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomActionPerformed
        String select = (String)room.getSelectedItem();
         if ("Standard".equals(select)){
             total.setText("1500");
         }else if ("Deluxe".equals(select)){
             total.setText("2000");
         }else if ("Premium".equals(select)){
             total.setText("3000");
         }else if ("Regency".equals(select)){
             total.setText("3500");
         }
    }//GEN-LAST:event_roomActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reserve.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(reserve.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(reserve.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(reserve.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new reserve().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton delete;
    private javax.swing.JTextField in;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField name;
    private javax.swing.JTextField num;
    private javax.swing.JTextField out;
    private javax.swing.JComboBox<String> room;
    private javax.swing.JButton save;
    private javax.swing.JTable table;
    private javax.swing.JTextField total;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
